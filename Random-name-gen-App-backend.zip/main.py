import random

print('Welcome to the random name generator.\n')
print('To stop the program,\nenter "stop" at any time.\n')

def Main():

  switch = True

  while switch:
    Fnames = ['Liam','Noah', 'William', 'James', 'Oliver', 'Benjamin', 'Elijah', 'Lucas', 'Mason', 'Logan', 'Alexander', 'Ethan', 'Jacob', 'Michael', 'Daniel', 'Henry', 'Jackson', 'Sebastian', 'Aiden', 'Matthew', 'Samuel', 'David', 'Joseph', 'Carter', 'Owen', 'Wyatt', 'John', 'Jack', 'Luke', 'Jayden', 'Dylan', 'Grayson', 'Levi','Isaac', 'Gabriel', 'Julian', 'Mateo', 'Anthony', 'Jaxon', 'Lincoln', 'Joshua', 'Christopher', 'Andrew', 'Theodore', 'Caleb', 'Ryan', 'Asher', 'Nathan', 'Thomas', 'Leo', 'Isaiah', 'Charles', 'Josiah', 'Hudson', 'Christian', 'Hunter', 'Connor', 'Eli', 'Ezra', 'Aaron', 'Landon', 'Adrian', 'Jonathan', 'Nolan', 'Jeremiah', 'Easton', 'Elias', 'Colton', 'Cameron', 'Carson','Robert', 'Angel', 'Maverick','Nicholas', 'Dominic', 'Jaxson', 'Greyson', 'Adam', 'Ian', 'Austin', 'Santiago', 'Jordan','Cooper','Brayden', 'Roman','Evan','Ezekiel', 'Xavier', 'Jose', 'Jace', 'Jameson', 'Leonardo', 'Bryson', 'Axel','Everett', 'Parker', 'Kayden', 'Miles', 'Sawyer', 'Jason', 'Emma','Olivia','Ava','Isabella','Sophia','Charlotte','Mia','Amelia','Harper','Evelyn','Abigail','Emily','Elizabeth','Mila','Ella','Avery','Sofia','Camila','Aria','Scarlett','Victoria','Madison','Luna','Grace','Chloe','Penelope','Layla','Riley','Zoey','Nora','Lily','Eleanor','Hannah','Lillian','Addison','Aubrey','Ellie','Stella','Natalie','Zoe','Leah','Hazel','Violet','Aurora','Savannah','Audrey','Brooklyn','Bella','Claire','Skylar','Lucy','Paisley','Everly','Anna','Caroline','Nova','Genesis','Emilia','Kennedy','Samantha','Maya','Willow','Kinsley','Naomi','Aaliyah','Elena','Sarah','Ariana','Allison','Gabriella','Alice','Madelyn','Cora','Ruby','Eva','Serenity','Autumn','Adeline','Hailey','Gianna','Valentina','Isla','Eliana','Quinn','Nevaeh','Ivy','Sadie','Piper','Lydia','Alexa','Josephine','Emery','Julia','Delilah','Arianna','Vivian','Kaylee','Sophie','Brielle','Madeline']

    Lnames = ['Castaneda','Figueroa','Sutton','Long','Perry','Richardson','Carroll','Warner','Rossi','Harvey','Newman','Black','Jacobs','Williams','Jimenez','Bull','Rojas','Bryan','Cunningham','Bishop','Coles','Webster','Turner','Whittaker','Rees','Ferguson','Pittman','Ford','Gomez',"O'Moore",'Armstrong','Beck','Peters','Dixon','Ortega','Carr','Miller','Brewer','Goodwin','Bond','Russell','Chapman','Coates','Myers','Warren','Rawlings','Singh','Cabrera','Gibbons','Butler','Barret','Coleman','Hudson','Moore','Clark','Clayton','Ward','Davidson','Soto','Mckinney','Powers','Anderson','Sinclair','Gonzales','Lawrence','Cross','Power','Paul','Atkinson','Holt','Fleming','Schneider','Wells','Blair','Dickson','Mcdonald','Rodriguez','Ramos',"O'Connor",'Roberts','Young','Osborne','Sanchez','Carlson','Tate','Gilbert','Vega','Smith','Ballard','Dawson','Dunn','Mason','Vincent',"Hunter","Reynolds","French","Kaur"]

    first = random.choice(Fnames)

    last = random.choice(Lnames)

    print('\nDo you want just a first name,\nor a first and last name?\n')


    string = input('\n> ').lower()
    print('\n')

    if 'first' in string:
      if 'both' in string or 'last' in string:
        print(f'{first} {last}')
      else:
        print(random.choice(Fnames))

    elif string == 'stop':
      switch = False

    else:
      print('This is not an operatable function.')

Main()

#Kivy
##Backend only 