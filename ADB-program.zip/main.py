exec(open('Program.py').read())

#FOR TESTING CONCEPTS#
#exec(open('Test.py').read())