#INSTALL ADB#

import os
import time
import sys



def Main():

  #Defining disconnect function#
  def Discon():
    os.system(f'adb disconnect 000.000.0.{IpAddress}')
    os.system('adb kill-server')
    exec(open('main.py').read())


  #Begin System Operation#
  os.system('adb kill-server')
  os.system('adb start-server')

  IpAddress = input('> ')

  #IP ADDRESS#
  os.system(f'adb connect 000.000.0.{IpAddress}')

  #Begins "USER INPUT" for sequence#











  #Long list of inputs needed... Ends here#

  #Questions - Can you use commnds such as 'os.system('adb shell input keyevent (char)/x')'
  #for long press: adb shell input keyevent --longpress #

  #After execution Ends#
  Discon()
Main()