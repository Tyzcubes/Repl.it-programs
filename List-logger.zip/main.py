#R = rows
#C = columns
#Columns = column names


print('This is a list logger.\nYou can have infinite columns and infinate rows.\n\nThe table is sideways...\nFor example:\n["ExampleTitle", "item"]\n["ExampleTitle", "item"]')
def ListCr():

  switch = True

  def CrCol():
    Columns = []
    List = []


    flip = True

    while flip:
      C = input('\n\nHow many rows do you want?\n (Enter an integer.)\n\n >')

      try:
        C = int(C)
        cS = int(C)

      except ValueError:
        print('\nThis is not an integer.\n\n\n')

      CC = C

      if C == 0:
        print('\nUndefined\n\n\n')
        flip = False
      elif C > 0:
        print('\nWhat are the names of your rows?\n(From top to bottom.)\n')
        while C > 0:
          Q = input('\n>')
          Columns.append(Q)
          C -= 1
        R = input('\nHow many columns do you want? (Integer)\n\n >')

        try:
          R = int(R)
          rS = int(R)
          rS2 = int(R)
         

        except ValueError:
          print('This is not an integer.\n\n\n')

        if R == 0:
          print('\nUndefined\n\n\n')
          flip = False

        curCol = -1
        while cS > 0:
          curCol += 1
          tempList = []
          rS2 = rS
          while rS2 != 0:
            colRows = input(f'\nWhat are the items under row "{Columns[curCol]}"?\n(Left to right.)\n\n >')
            tempList.append(colRows)
            rS2 -= 1
          List.append(f'{Columns[curCol]}: {tempList}')
          cS -= 1

        
        print(*List, sep = "\n")
          



        


        
      

      
        


        


    

 
  while switch:
    CrCol()
ListCr()