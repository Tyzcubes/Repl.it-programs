import os
import sys

def fun1():
  done = False

  #Exit Function#
  
  while done == False:

    print('Enter a # for however many times you wish to run the command.\n')
    print('Enter stop to end program.\n')

    switch = True

    while switch:
      x = ''
      def Ifun1():
        def Sfun():
          if x == 'stop':
            exit()
        def Ifun2():
          os.system('ls')
        x = input('> ').lower()
        print('\n')
        Sfun()
        try:
          y = int(x)
          while y > 0:
            Ifun2()
            y -= 1
          switch = False
        except ValueError:
          print('This is not an operatable function.\n\n\n\n')
      Ifun1()

while True:
  fun1()